<?php

class Configuracion {
    
    const PERMISOS = 777;
    const SERVIDOR = "localhost";
    const BASEDATOS = "test";
    const USUARIO = "root";
    const CLAVE = "";
    const PEZARANA = "pez araña";
    const ORIGENGMAIL = "correo@gmail.com";
    const CLAVEGMAIL = "*******";
    const RPP = 2;
    const TIMEOUT = 1800;
}