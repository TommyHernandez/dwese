<hr>
<footer>
    <p>&copy; PHP-MVC</p>
</footer>