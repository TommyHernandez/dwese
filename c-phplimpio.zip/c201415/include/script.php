<script src="<?php echo $dir;?>js/vendor/jquery-1.11.1.js"></script>
<script src="<?php echo $dir;?>js/vendor/bootstrap.min.js"></script>
<script src="<?php echo $dir;?>js/vendor/toast/toastr.js"></script>
<script src="<?php echo $dir;?>js/ajax.js"></script>
<script src="<?php echo $dir;?>js/codigo.php?<?php echo "mensaje=$mensaje&tipo=$tipo";?>"></script>
<script src="<?php echo $dir;?>js/codigo.js"></script>