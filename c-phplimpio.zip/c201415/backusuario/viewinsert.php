<?php
require '../require/comun.php';
$actual = "usuario";
$dir = "../";
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ("../include/head.php"); ?>
        <title>../dwes</title>
    </head>
    <body>
        <?php include ("../include/barranavegacion.php"); ?>
        <div class="jumbotron" style="padding: 10px;">
            <div class="container">
                <h2 style="float: left;">Usuario</h2>
            </div>
        </div>
        <div class="container">
            <div class="row" >
                <div>
                    <form method="post" action="phpinsert.php">
                        <table>
                            <tr>
                                <td>login</td>
                                <td>
                                    <input type="text" name="login" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>clave</td>
                                <td>
                                    <input type="text" name="clave" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>nombre</td>
                                <td>
                                    <input type="text" name="nombre" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>apellidos</td>
                                <td>
                                    <input type="text" name="apellidos" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>email</td>
                                <td>
                                    <input type="text" name="email" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>rol</td>
                                <td>
                                    <!--<input type="text" name="rol" value="" />-->
                                    <?php echo Util::getRol("", "rol", "rol", false); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>is root</td>
                                <td>
                                    <!--<input type="text" name="isroot" value="" />-->
                                    <?php echo Util::getSiNo("", "isroot", "isroot", false); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>is activo</td>
                                <td>
                                    <!--<input type="text" name="isactivo" value="" />-->
                                    <?php echo Util::getSiNo("", "isactivo", "isactivo", false); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>fecha alta</td>
                                <td>
                                    <input type="text" name="fechaalta" value="" disabled="" />
                                </td>
                            </tr>
                            <tr>
                                <td>fecha login</td>
                                <td>
                                    <input type="text" name="fechalogin" value="" disabled=""/>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <input type="submit" value="inserción" class="btn btn-success" />
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
            <?php include ("../include/pie.php"); ?>
        </div>
        <?php include ("../include/fondo.php"); ?>
        <?php include ("../include/script.php"); ?>
    </body>
</html>